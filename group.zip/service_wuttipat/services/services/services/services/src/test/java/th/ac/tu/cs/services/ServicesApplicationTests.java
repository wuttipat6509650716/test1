package th.ac.tu.cs.services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
