package th.ac.tu.cs.services.model;

public class contact {

    public contact(){
    }

    public contact(String date, String studentFirstName, String studentLastName, String studentId, String studentYear, String studyField,
                   String advisor, String addressNumber, String moo, String tumbol, String amphur, String province, String postalCode, String mobilePhone,
                   String phone, String cause, String nadd, String ndrop, String subjectCodeAdd, String subjectNameAdd, String subjectSectionAdd,
                   String subjectDateAdd, String subjectCreditAdd, String subjectTeacherAdd, String subjectTeacherCheckAdd, String subjectCodeDrop, String subjectNameDrop,
                   String subjectSectionDrop, String subjectDateDrop, String subjectCreditDrop, String subjectTeacherDrop, String subjectTeacherCheckDrop){
        this.date = date;
        this.studentFirstName = studentFirstName;
        this.studentLastName = studentLastName;
        this.studentId = studentId;
        this.studentYear = studentYear;
        this.studyField = studyField;
        this.advisor = advisor;
        this.addressNumber = addressNumber;
        this.moo = moo;
        this.tumbol = tumbol;
        this.amphur = amphur;
        this.province = province;
        this.postalCode = postalCode;
        this.mobilePhone = mobilePhone;
        this.phone = phone;
        this.cause = cause;

        this.nadd = nadd;
        this.ndrop = ndrop;
        this.subjectCodeAdd = subjectCodeAdd;
        this.subjectNameAdd = subjectNameAdd;
        this.subjectSectionAdd = subjectSectionAdd;
        this.subjectDateAdd = subjectDateAdd;
        this.subjectCreditAdd = subjectCreditAdd;
        this.subjectTeacherAdd = subjectTeacherAdd;
        this.subjectTeacherCheckAdd = subjectTeacherCheckAdd;

        this.subjectCodeDrop = subjectCodeDrop;
        this.subjectNameDrop = subjectNameDrop;
        this.subjectSectionDrop = subjectSectionDrop;
        this.subjectDateDrop = subjectDateDrop;
        this.subjectCreditDrop = subjectCreditDrop;
        this.subjectTeacherDrop = subjectTeacherDrop;
        this.subjectTeacherCheckDrop = subjectTeacherCheckDrop;
    }


    private String date;

    private String studentFirstName;

    private String studentLastName;

    private String studentId;

    private String studentYear;

    private String studyField;

    private String advisor;

    private String addressNumber;

    private String moo;

    private String tumbol;

    private String amphur;

    private String province;

    private String postalCode;

    private String mobilePhone;

    private String phone;

    private String cause;

    private String nadd;

    private String ndrop;

    private String subjectCodeAdd;

    private String subjectNameAdd;

    private String subjectSectionAdd;

    private String subjectDateAdd;

    private String subjectCreditAdd;

    private String subjectTeacherAdd;

    private String subjectTeacherCheckAdd;

    private String subjectCodeDrop;

    private String subjectNameDrop;

    private String subjectSectionDrop;

    private String subjectDateDrop;

    private String subjectCreditDrop;

    private String subjectTeacherDrop;

    private String subjectTeacherCheckDrop;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStudentFirstName() {
        return studentFirstName;
    }

    public void setStudentFirstName(String studentFirstName) {
        this.studentFirstName = studentFirstName;
    }

    public String getStudentLastName() {
        return studentLastName;
    }

    public void setStudentLastName(String studentLastName) {
        this.studentLastName = studentLastName;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentYear() {
        return studentYear;
    }

    public void setStudentYear(String studentYear) {
        this.studentYear = studentYear;
    }

    public String getStudyField() {
        return studyField;
    }

    public void setStudyField(String studyField) {
        this.studyField = studyField;
    }

    public String getAdvisor() {
        return advisor;
    }

    public void setAdvisor(String advisor) {
        this.advisor = advisor;
    }

    public String getAddressNumber() {
        return addressNumber;
    }

    public void setAddressNumber(String addressNumber) {
        this.addressNumber = addressNumber;
    }

    public String getMoo() {
        return moo;
    }

    public void setMoo(String moo) {
        this.moo = moo;
    }

    public String getTumbol() {
        return tumbol;
    }

    public void setTumbol(String tumbol) {
        this.tumbol = tumbol;
    }

    public String getAmphur() {
        return amphur;
    }

    public void setAmphur(String amphur) {
        this.amphur = amphur;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    public String getNadd() {
        return nadd;
    }

    public void setNadd(String nadd) {
        this.nadd = nadd;
    }

    public String getNdrop() {
        return ndrop;
    }

    public void setNdrop(String ndrop) {
        this.ndrop = ndrop;
    }

    public String getSubjectCodeAdd() {
        return subjectCodeAdd;
    }

    public void setSubjectCodeAdd(String subjectCodeAdd) {
        this.subjectCodeAdd = subjectCodeAdd;
    }

    public String getSubjectNameAdd() {
        return subjectNameAdd;
    }

    public void setSubjectNameAdd(String subjectNameAdd) {
        this.subjectNameAdd = subjectNameAdd;
    }

    public String getSubjectSectionAdd() {
        return subjectSectionAdd;
    }

    public void setSubjectSectionAdd(String subjectSectionAdd) {
        this.subjectSectionAdd = subjectSectionAdd;
    }

    public String getSubjectDateAdd() {
        return subjectDateAdd;
    }

    public void setSubjectDateAdd(String subjectDateAdd) {
        this.subjectDateAdd = subjectDateAdd;
    }

    public String getSubjectCreditAdd() {
        return subjectCreditAdd;
    }

    public void setSubjectCreditAdd(String subjectCreditAdd) {
        this.subjectCreditAdd = subjectCreditAdd;
    }

    public String getSubjectTeacherAdd() {
        return subjectTeacherAdd;
    }

    public void setSubjectTeacherAdd(String subjectTeacherAdd) {
        this.subjectTeacherAdd = subjectTeacherAdd;
    }

    public String getSubjectTeacherCheckAdd() {
        return subjectTeacherCheckAdd;
    }

    public void setSubjectTeacherCheckAdd(String subjectTeacherCheckAdd) {
        this.subjectTeacherCheckAdd = subjectTeacherCheckAdd;
    }

    public String getSubjectCodeDrop() {
        return subjectCodeDrop;
    }

    public void setSubjectCodeDrop(String subjectCodeDrop) {
        this.subjectCodeDrop = subjectCodeDrop;
    }

    public String getSubjectNameDrop() {
        return subjectNameDrop;
    }

    public void setSubjectNameDrop(String subjectNameDrop) {
        this.subjectNameDrop = subjectNameDrop;
    }

    public String getSubjectSectionDrop() {
        return subjectSectionDrop;
    }

    public void setSubjectSectionDrop(String subjectSectionDrop) {
        this.subjectSectionDrop = subjectSectionDrop;
    }

    public String getSubjectDateDrop() {
        return subjectDateDrop;
    }

    public void setSubjectDateDrop(String subjectDateDrop) {
        this.subjectDateDrop = subjectDateDrop;
    }

    public String getSubjectCreditDrop() {
        return subjectCreditDrop;
    }

    public void setSubjectCreditDrop(String subjectCreditDrop) {
        this.subjectCreditDrop = subjectCreditDrop;
    }

    public String getSubjectTeacherDrop() {
        return subjectTeacherDrop;
    }

    public void setSubjectTeacherDrop(String subjectTeacherDrop) {
        this.subjectTeacherDrop = subjectTeacherDrop;
    }

    public String getSubjectTeacherCheckDrop() {
        return subjectTeacherCheckDrop;
    }

    public void setSubjectTeacherCheckDrop(String subjectTeacherCheckDrop) {
        this.subjectTeacherCheckDrop = subjectTeacherCheckDrop;
    }

}
